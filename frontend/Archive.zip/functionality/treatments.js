const treatment = {
  English: {
    dentalCalculus: "Cleaning of teeth along with polishing",
    dentalStain: "Cleaning of teeth along with polishing",
    spacesBetweenTeeth: "Apply teeth crown and venners",
    dentalCavity: "Filling and restoration of teeth",
  },
  Hindi: {
    dentalCalculus: "दांतो की सफाई एवं पोलिशिंग",
    dentalStain: "दांतो की सफाई एवं पोलिशिंग",
    spacesBetweenTeeth: "मसाला भरवाना एवं कैप या कवर लगाना",
    dentalCavity: "मसाला भरवाना एवं कैप या कवर लगाना",
  },
};
export default treatment;
